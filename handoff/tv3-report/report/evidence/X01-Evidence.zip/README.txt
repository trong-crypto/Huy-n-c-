X01 evidence for group 12, Huyen Co, 2026-10-29.
Entries retain their paths relative to the project root.
MANIFEST.json hashes every payload entry; original artifact bytes were not edited.
There are 46027 eligible measurement requests and one SEND 0.022 ms outside the window.
The original matrix is not a strict-window PASS.
See report/README.md and docs/54-X01-REPORT-HANDOFF.md.
Check package integrity with SHA-256 and MANIFEST.json after extraction.
No JAR, database dump or book PDF is bundled. Original absolute paths refer to the measurement machine.
Running the original auditors again requires their pinned JAR/source and the prepared TEST environment.
This archive does not submit a report or assert a Compilatio result.
